/* ========================================
 *  PSoC Pong
 *  The purpose of this program is to demonstrate the use of the adafruit GFX library ported to PSoC
 *
 *
 * Written by: Jonathan Isaiah (strayVoltage)  earthworm.jim117@gmail.com
 * Copyright 2015 Jonathan Isaiah GNU GPL V3 - Legal Info at End of File
 * ========================================
*/
#include <project.h>
#include <stdlib.h>


#include "ssd1306.h"
#include "GFXmaster.h"

#define NO_FINGER 0xFFFFu

int main()
{
    
    uint16 sliderPosition = NO_FINGER;
    uint16 lastPosition = NO_FINGER;
    
    CyGlobalIntEnable; /* Enable global interrupts. */
    CyDelay(150);
    
    CapSense_1_Start();
    CapSense_1_InitializeAllBaselines();
    
    
    /* Change SCL and SDA pins drive mode to Resistive Pull Up */
    I2C_bus_scl_SetDriveMode(I2C_bus_scl_DM_RES_UP);
    I2C_bus_sda_SetDriveMode(I2C_bus_sda_DM_RES_UP);
    I2C_bus_Start();
    CyDelay(150);
    
    GFX_Init(64, 128);
    ssd1306_init_routine();
    ssd1306_display();
    
    CyDelay(1000);
    
    ssd1306_clearDisplay();
    ssd1306_display();
    CyDelay(1000);
    
   uint16_t sliderMax = 102;  //hodge podge math, this value determined experimentally, not really slidermax
 
    
   uint8_t gamestate = 0; // 0: splash screen  1: menu*not implemented*   2:playing game    3: game lost   4: game won*not implemented*
   int16_t ballX, ballY = 30;
   int8_t ballVelX = 1;
   int8_t ballVelY = 2;
   uint8_t ballRadius = 3;
   
   uint8_t leftPaddleHeight = 10;
   uint8_t rightPaddleHeight = 15;
   
   int16_t rightPaddlePos = 30;
   int16_t leftPaddlePos = 40;
    
   uint8_t leftPaddleSpeed = 2;
   uint8_t rightPaddleSpeed = 2;
   
    
    /* Place your initialization/startup code here (e.g. MyInst_Start()) */

    for(;;)
    {
        if(gamestate == 0){
            ssd1306_clearDisplay();
            
            drawCircle(ballX, ballY, ballRadius, 1);
            
            ballX = ballX + ballVelX;
            ballY = ballY + ballVelY;
            
            //left paddle  
            if(ballX <= 64){          
                if(ballY > leftPaddlePos){
                    leftPaddlePos = leftPaddlePos + leftPaddleSpeed;
                }
                else if(ballY < leftPaddlePos){
                    leftPaddlePos = leftPaddlePos - leftPaddleSpeed;
                }
            }
            drawFastVLine(0, leftPaddlePos-leftPaddleHeight/2, leftPaddleHeight, 1);
            
            
            
            //right paddle
            if(ballX >= 64){
                if(ballY > rightPaddlePos){
                    rightPaddlePos = rightPaddlePos + rightPaddleSpeed;
                }
                else if(ballY < rightPaddlePos){
                    rightPaddlePos = rightPaddlePos - rightPaddleSpeed;
                }           
            }
            drawFastVLine(127, rightPaddlePos-rightPaddleHeight/2, rightPaddleHeight, 1); 
            
            
            
            
            //ball movement
            if(ballX < 4){
             ballX = 4;
             ballVelX = -ballVelX;   
            }
            else if(ballX > 124){
                ballX = 124;
                ballVelX = -ballVelX;
            }
            
            if(ballY < 4){
             ballY = 4;   
             ballVelY = -ballVelY;   
            }
            else if(ballY>60){
                ballY=60;
                ballVelY = -ballVelY;
            }
            
            
            
            
            setCursor(2, 30);
            writeString("Welcome to PSoC Pong");
            ssd1306_display();
            
            if(!Button_1_Read()){
                gamestate = 2;
                
                ballX = 64;
                ballY = 30;
            }
            //CyDelay(0);
        }
        
        else if(gamestate == 1){
            
        }
        
        else if (gamestate == 2){
            ssd1306_clearDisplay();
            
            
             //player paddle (right)  
            CapSense_1_UpdateEnabledBaselines();
            CapSense_1_ScanEnabledWidgets();
            while(CapSense_1_IsBusy());
            
            sliderPosition = CapSense_1_GetCentroidPos(CapSense_1_LINEARSLIDER0__LS);
            
            /*If finger is detected on the slider*/
    		if(sliderPosition != NO_FINGER)
    		{
    			/* If finger position on the slider is changed then update the right bumper position */
            	if(sliderPosition != lastPosition)
            	{
                   rightPaddlePos = sliderPosition*63 / sliderMax;   
                   if(rightPaddlePos < 0+rightPaddleHeight/2){
                        rightPaddlePos = 0+rightPaddleHeight/2;
                   }
                   else if(rightPaddlePos > 63){
                        rightPaddlePos = 63;
                   }
            	}
    		}
            
                               
            drawFastVLine(127, rightPaddlePos-rightPaddleHeight/2, rightPaddleHeight, 1); 
            
            
            
            //left paddle  
            if(ballX <= 64){          
                if(ballY > leftPaddlePos){
                    leftPaddlePos = leftPaddlePos + leftPaddleSpeed;
                }
                else if(ballY < leftPaddlePos){
                    leftPaddlePos = leftPaddlePos - leftPaddleSpeed;
                }
            }
            drawFastVLine(0, leftPaddlePos-leftPaddleHeight/2, leftPaddleHeight, 1);
            
            
            //ball movement vertical
            ballX = ballX + ballVelX;
            ballY = ballY + ballVelY;
            
            if(ballY < 4){
             ballY = 4;   
             ballVelY = -ballVelY;   
            }
            else if(ballY>60){
                ballY=60;
                ballVelY = -ballVelY;
            }
            
            //ball movement horizontal
            if(ballX < 4){
             ballX = 4;
             ballVelX = -ballVelX;   
            }
            else if(ballX > 124){
                if(      abs((rightPaddlePos + rightPaddleHeight/2)-(rightPaddleHeight/2)-ballY) < (ballRadius + rightPaddleHeight/2) ){ //top half of paddle doesnt work
                    ballX = 124; //^^^^^^^^^^^^^^fix top half of paddle math later ^^^^^^^^^^^^^^^^^^^^^^^^^^^^
                    ballVelX = -ballVelX;
                }
                else{gamestate = 3;}
            }
            
            drawCircle(ballX, ballY, ballRadius, 1);
            ssd1306_display();
        }
        
        else if(gamestate == 3){
            
          ssd1306_clearDisplay();   
          setCursor(2, 30);
          writeString("You Lose, Meatbag");
          ssd1306_display();
        
          if(!Button_1_Read()){
                CyDelay(150);
                gamestate = 0;                
                ballX = 64;
                ballY = 30;
          }
        }
    }
}





/*
    This file is part of PSoC Pong.

    PSoC Pong is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    PSoC Pong is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with PSoC Pong.  If not, see <http://www.gnu.org/licenses/>.


*/

   
/* [] END OF FILE */
